--
-- PostgreSQL database dump
--

-- Dumped from database version 11.2 (Debian 11.2-1.pgdg90+1)
-- Dumped by pg_dump version 11.2 (Debian 11.2-1.pgdg90+1)

-- Started on 2023-12-11 17:06:40 UTC

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- TOC entry 199 (class 1259 OID 16394)
-- Name: customer; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.customer (
    id bigint NOT NULL,
    username character varying(20) NOT NULL,
    password character varying(60),
    name character varying(20),
    surname character varying(20),
    address character varying(60),
    email character varying(50),
    card_type character varying(30)
);


ALTER TABLE public.customer OWNER TO postgres;

--
-- TOC entry 198 (class 1259 OID 16392)
-- Name: customer_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.customer_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.customer_id_seq OWNER TO postgres;

--
-- TOC entry 2895 (class 0 OID 0)
-- Dependencies: 198
-- Name: customer_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.customer_id_seq OWNED BY public.customer.id;


--
-- TOC entry 201 (class 1259 OID 16402)
-- Name: customer_order; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.customer_order (
    id bigint NOT NULL,
    customer_id bigint NOT NULL,
    product_id bigint NOT NULL,
    quantity integer NOT NULL,
    price numeric(10,2) NOT NULL,
    currency character(3) NOT NULL
);


ALTER TABLE public.customer_order OWNER TO postgres;

--
-- TOC entry 200 (class 1259 OID 16400)
-- Name: customer_order_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.customer_order_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.customer_order_id_seq OWNER TO postgres;

--
-- TOC entry 2896 (class 0 OID 0)
-- Dependencies: 200
-- Name: customer_order_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.customer_order_id_seq OWNED BY public.customer_order.id;


--
-- TOC entry 197 (class 1259 OID 16386)
-- Name: product; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.product (
    id bigint NOT NULL,
    name character varying(50) NOT NULL,
    currency character(3) NOT NULL,
    price numeric(10,2) NOT NULL
);


ALTER TABLE public.product OWNER TO postgres;

--
-- TOC entry 196 (class 1259 OID 16384)
-- Name: product_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.product_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.product_id_seq OWNER TO postgres;

--
-- TOC entry 2897 (class 0 OID 0)
-- Dependencies: 196
-- Name: product_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.product_id_seq OWNED BY public.product.id;


--
-- TOC entry 2753 (class 2604 OID 16397)
-- Name: customer id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer ALTER COLUMN id SET DEFAULT nextval('public.customer_id_seq'::regclass);


--
-- TOC entry 2754 (class 2604 OID 16405)
-- Name: customer_order id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer_order ALTER COLUMN id SET DEFAULT nextval('public.customer_order_id_seq'::regclass);


--
-- TOC entry 2752 (class 2604 OID 16389)
-- Name: product id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product ALTER COLUMN id SET DEFAULT nextval('public.product_id_seq'::regclass);


--
-- TOC entry 2887 (class 0 OID 16394)
-- Dependencies: 199
-- Data for Name: customer; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.customer (id, username, password, name, surname, address, email, card_type) FROM stdin;
1	ogannicott0	$2a$04$iMUWSjcwbXtLOl0jr0zHK.A0JmnNNwzBUyHVIDY8ZGD2T01pEobO2	Osborn	Gannicott	38 Sutteridge Park	feades0@pinterest.com	jcb
2	gcroley1	$2a$04$1ACp.Oa0jbiEeQRY8h4iK.fyjFAeVdHNYfF4wKld7mDyURSrFG7dq	Glyn	Croley	1 Thackeray Street	sstryde1@youku.com	visa
3	cjozefiak2	$2a$04$OTn31.ZBtLfzepA5Isnzoe38//Yu/StonrAfu.LySP6wf3iQ5u8OG	Celka	Jozefiak	74 Lake View Circle	mveness2@examiner.com	china-unionpay
4	santonetti3	$2a$04$jxCGF3KDorVaO5l86k1fN.KcxrssV48zz0tOCEd2AwjiwnW04Jxg6	Sonja	Antonetti	7 Rieder Plaza	sbrotherheed3@abc.net.au	instapayment
5	bbrixey4	$2a$04$pAMItoCQwSK2Cq9Ske365.Bd4BH8g9ssjchae8HFfhFDmRWNkUgRq	Basilius	Brixey	54329 Hollow Ridge Alley	atempleman4@imgur.com	mastercard
6	hcoombe5	$2a$04$txJAlQdQngm2wln27ri4TuAEDBGnS.MhSyKY7flDB6fmKkkP75Q3C	Hermie	Coombe	6 Kenwood Street	lboskell5@biglobe.ne.jp	americanexpress
7	nleathes6	$2a$04$APSx5OmQNwit5fdqgFVtBOCJqnB2jKENIWQFQ2sm.DvzONrQcXodi	Nancey	Leathes	506 Oriole Court	mtyrrell6@webs.com	mastercard
8	icawston7	$2a$04$wZphT2yEAerb1HVZ.EogaOlmjaD5nj3cCCcAiULMsLReKlwz7XXES	Ingeberg	Cawston	6665 Blaine Place	hkirman7@nps.gov	jcb
9	fwolverson8	$2a$04$OTDKmEqMz91XJ.bMkVN9beXSXTZZr6UvsjmI8CVfJ4zrXvsQbIFci	Francklyn	Wolverson	181 Sachtjen Circle	oshowte8@example.com	bankcard
10	lbotfield9	$2a$04$S9LXOk1mQe9V5m2.3xu.ienv8BH19NsU7j6SKf765KOmuRpLVFLPu	Lauralee	Botfield	4182 Menomonie Parkway	ghothersall9@naver.com	visa-electron
11	wcostelowa	$2a$04$BEe6Bqpp9DAvfl76Vhpc5ez3inM5g1MiwbKy2H0yr44yUDUlOIFEq	Wakefield	Costelow	6362 Straubel Parkway	gauthersa@storify.com	jcb
12	dedgsonb	$2a$04$/snob2fJmB31e1JxClbGm.i19yALH.CFfL9fOTw4NN1iNRSnruy0.	Derick	Edgson	410 Aberg Parkway	dkarbyb@privacy.gov.au	instapayment
13	mklischc	$2a$04$fMHAKKDhcdeUwFNVbXhBpucgkilxrA3UWmbULxYmm2gm3cKjeahd6	Myrta	Klisch	7 Moland Lane	mnoltonc@dot.gov	laser
14	syoungsd	$2a$04$gXCBRLEeZEbUO4LnETgGVOKu6rfRcn3wRdITS.x.CWq37AtR5uV5S	Scotty	Youngs	28 Tomscot Hill	epennickd@marriott.com	americanexpress
15	epettitte	$2a$04$8KWN6GIC7mLBoH4xvPt5WujnjTECTFn7lnVvXeTnECwf//6mxblWC	Elana	Pettitt	9 Mifflin Trail	cmacguffiee@hc360.com	visa-electron
16	lbokenf	$2a$04$OfPjt0OdxxE/rHGHYrPhaumeENqbQdi8BSms61XOmMDZWywkb4tIS	Lolita	Boken	7 Lukken Parkway	fmacbeyf@miibeian.gov.cn	americanexpress
17	bebbottsg	$2a$04$KTmvSXpQGZF.XlyecwyI9e5HkT8w7PPb.4MfEp5IjWQpy9lD6MBCC	Bord	Ebbotts	32101 Charing Cross Park	ktombsg@answers.com	jcb
18	lhegdenh	$2a$04$mZDrjFYL5d2k1aJV4ZK/K.56.3wK3n4Sq8MZatvGizlG3bPoCPQm2	Lurline	Hegden	83 Homewood Place	mshoulderh@google.es	diners-club-carte-blanche
19	kconradi	$2a$04$VPFjOEZ5287VRanbg4xtSuSXLJjQJHs/9Zfyqtas7qfHCgzKP/79a	Kelsy	Conrad	1245 Cascade Way	bsiviouri@mapy.cz	americanexpress
20	gpannettj	$2a$04$PIWij7ufHvCYRQuMgV535uZVe40jUIUYIwlpO1oCmj.k9rrS03/Sy	Gayler	Pannett	77652 West Plaza	sottewillj@themeforest.net	jcb
21	hcominettik	$2a$04$0FmE034LNPbLj9i/KiuAAeDhy0cRiELAYo8C1b5vGmFfTEz3C3JCi	Hertha	Cominetti	745 Kensington Way	kbodycombek@tuttocitta.it	diners-club-carte-blanche
22	rbenazetl	$2a$04$rFRaNYl0QjYCAsNwkSlMj.EbbC9cLbtuCjjZKzFhdgSdtJipgdDgO	Ring	Benazet	51 Carioca Circle	pkeesl@marriott.com	maestro
23	mgorvettem	$2a$04$5/7cL.5sEXZ91pGZ/4QWbecWMBksvDt0M6Pm7N4.YM7R3S96AkaI6	Minna	Gorvette	08 Mariners Cove Street	lcastellinim@artisteer.com	switch
24	cberzenn	$2a$04$bBW7ccdom9fHsqQFCChb8.XqZ0fLizWjwYyjiunjWTIPf7rBywXEa	Cesare	Berzen	99 Del Sol Place	lastlingn@netvibes.com	jcb
25	cslorao	$2a$04$cEYCYWbX1Coj81VD0fTEbetLd68YTm6Q8j2gSDeoRG/.O2XzDUHzq	Cornela	Slora	252 Brentwood Street	brobardeyo@baidu.com	jcb
26	lfidelerp	$2a$04$lC5R1H9fEfzkNkWRaTe5F.gtkG3/LzQLk4zaW1yiNAffud3hFjk6q	Lanna	Fideler	13 John Wall Trail	mriccip@java.com	jcb
27	ngonnardq	$2a$04$zv5iSFws/po3DPLaP6CxsuT8v0Q0Mf7K7B3tnsk304W9t9xGWWpEG	Nevin	Gonnard	8 Tennessee Center	rpavlishchevq@ucoz.ru	maestro
28	dlittlefairr	$2a$04$8r8elyjiMOHVYScACDuYKOsZuh4Zl4gEtYxsf4kwtz9KnYl6w/EXu	Domini	Littlefair	411 Pond Junction	hpaszekr@ezinearticles.com	jcb
29	asherstons	$2a$04$HVxojI0c9ZM8qe0LcPHdc.4eX6wfR6ytib8FTK7XCq/bGCEjOJC/y	Almeta	Sherston	959 Hooker Alley	gbuchams@jiathis.com	bankcard
30	rwiffent	$2a$04$J/7Au67PiM5agjF4dI4eBOjQx04UCVuNc7c7S/HfnctXkyedPhIFS	Rosabel	Wiffen	9 Hanson Crossing	jmeneghellit@shutterfly.com	jcb
31	bskermanu	$2a$04$TfYNC.JC8jWDiT2xmmwIAeqDyfIU7jXZ.Au51M20udj5tC76t4E1C	Betty	Skerman	670 Graceland Alley	jjeannardu@wix.com	mastercard
32	lplaydonv	$2a$04$xtXc5WCiA0Tbuww4.qg2wuUCvye0vWsO7V6L1q5L234cUiNpXCWKK	Lesley	Playdon	18281 Portage Circle	vsapsonv@cbc.ca	jcb
33	jashforthw	$2a$04$tuMD4VGfthv7exbowQfpA.D89EbM7dlnd6NKuys46NsudW2GXWGSq	Jorrie	Ashforth	6 Stang Junction	utwiggerw@dedecms.com	jcb
34	cmooreedx	$2a$04$eC60Yk.Y/rvm2JFZKGRzXeZUhumNzAPEENhFwG8/G60vkeIKyS7Ie	Caressa	Mooreed	3 Talmadge Alley	cswatmanx@oaic.gov.au	diners-club-enroute
35	aandrichaky	$2a$04$SHuGUAnfclK8HF5IA8QTNeV80OgHcXMnxc/oz3H0Almrwn0RvBQ5i	Annie	Andrichak	629 Ridge Oak Lane	kranyardy@twitter.com	jcb
36	kbrazz	$2a$04$DQwOSOw58N1rUDPbrxaXz.RemMP8Q6A8NuCwgKd6wNMi5L0Tqj0J.	Kelcie	Braz	38 Continental Court	arowlyz@tinypic.com	jcb
37	rtixier10	$2a$04$j0MayG19CRfTN73lx4anL.eraKcGP/XdpUbyP.tfwZX4Twdh.bCfW	Rabbi	Tixier	310 Independence Drive	cgraves10@discuz.net	switch
38	jrowlin11	$2a$04$ue4bBMWIKxwJrFoQgal5X.By9KGNo/E5jocIMph7kwGRSO9wSQxaW	Judon	Rowlin	60410 Manufacturers Circle	sallchin11@aboutads.info	mastercard
39	vlowdes12	$2a$04$bjgF9vlS6nPdSEoW/P.5weKCaDKZaQ9r4HK39vUmZOoAtMgr.KjBe	Veronica	Lowdes	613 Fulton Point	awatton12@moonfruit.com	jcb
40	rdownse13	$2a$04$1I9RZtOGIYknuNNl10kqyODp3.yZlwGNMNyupIboZ9tc1p.Dhrs9e	Rosy	Downse	516 Scoville Circle	eblinde13@cbc.ca	laser
41	sshilston14	$2a$04$Q6Iru172Zzd30chTjsarJOkwJIoJGEoBpNsZ/Ht9.Yj0/VLAeQYnK	Stesha	Shilston	9075 Milwaukee Lane	cdellabbate14@sina.com.cn	diners-club-us-ca
42	adaniells15	$2a$04$Om91N0xUxRcM/2Mocz.CgOZ77.ll8H1susjWrcemAwQKw9oe4AuvO	Annabell	Daniells	982 Monica Plaza	hclissett15@github.io	diners-club-carte-blanche
43	sbridywater16	$2a$04$EJ3UqYWqSZkMONlBbTjjZOwpMm.tg7o4/ByZc/LLRWeUwWplpAAhq	Sherlocke	Bridywater	89 Loomis Hill	hcleminshaw16@cbc.ca	jcb
44	nshillington17	$2a$04$Zk3HC8a8FeZKqRoGW9gLFu4EUdvQRAQl/0.ewPkvkSJxaZBNi8If.	Naoma	Shillington	48 Sachs Parkway	cmoyse17@squarespace.com	china-unionpay
45	rpittwood18	$2a$04$8Vp558yZqZfDz8ptEJKKSOZmFDoxF3mYVHwOT6LrNoIUHjI3RWzlm	Riannon	Pittwood	09 Dottie Plaza	ctremonte18@hibu.com	jcb
46	shounihan19	$2a$04$19ddUhBGIXlG7ca4jz1OLu54CKf6icgdXrKmLZBNxPr.9aq9BY49C	Salomo	Hounihan	00689 Darwin Street	ehayton19@economist.com	mastercard
47	eroos1a	$2a$04$9tY84OGQRTq9ydCcU3aLy.V6luACWll6//yPDaNq6rCCEpF2Qwjd.	Earle	Roos	64 Springs Junction	osainsbury1a@utexas.edu	jcb
48	cchastelain1b	$2a$04$y0/499LcGDOdigNCGdTb7efYTqHdMpAaQxBcTBdWrL0st7ZqLaJ7y	Courtnay	Chastelain	4845 Lakeland Pass	bebbutt1b@go.com	china-unionpay
49	edishman1c	$2a$04$nc/ekd/vL4tVghiAkC93suUTWWFQbvTRxNc8SoTRhzwDWSEhPl3cq	Elvin	Dishman	017 Center Street	gsinderland1c@paginegialle.it	americanexpress
50	jbasezzi1d	$2a$04$y59GuyyICBKswioVU8pbJ.PyNxVPtHEH0kWtX3R552DGeS.oNkN/.	Julio	Basezzi	1902 Grover Park	cmccaughey1d@slate.com	americanexpress
51	mbebbington1e	$2a$04$uLlZhtaucX0xtC2b/zf2leM1xG37LPQ731xNwLy.2JpM8pp6oy5F6	Michele	Bebbington	92256 Elgar Road	rsutty1e@theglobeandmail.com	mastercard
52	scrowson1f	$2a$04$xIgx0Y2L8CrO/0UoLiXxD.Z/0LuOFzjBQvp.fX8qDOUQz2qoZFly2	Sheilah	Crowson	133 Riverside Drive	rgrandin1f@webs.com	diners-club-us-ca
53	tfettes1g	$2a$04$2HbiUILWkeuhmoWH4gDFHOOsRDlzenRezXbZPn8MKfm/9RwMQBlX6	Towny	Fettes	279 Kipling Parkway	mvaughn1g@squidoo.com	mastercard
54	fhanniger1h	$2a$04$Kd7kUVR6P8D3Y2AAQsVVPOmuwhEevLw9oD.e45rG1tbq2cbFxGMJe	Fairlie	Hanniger	696 Truax Lane	rnowick1h@statcounter.com	jcb
55	jstaggs1i	$2a$04$mzNeTOhpmIJ/uKCS7jeCTOcy0eWSl9g7z8kXa8KctNx0bi6TPaWTW	Josi	Staggs	1 Havey Circle	lboar1i@google.co.jp	switch
56	jrollason1j	$2a$04$MbT.K9VSeOmzFf4Z/1HZgO378MQux8xzhB9ZK.5uyF9J7GPc6h8y2	Jerrine	Rollason	98100 Bobwhite Alley	hdunan1j@wikimedia.org	jcb
57	jtomenson1k	$2a$04$Dy9THoYQWhsckiXGAYEddOTSC/U1vJ61/fLa1zAWfjLZ6GOr7IhKi	Jessamine	Tomenson	0 Fairview Alley	bspendley1k@usgs.gov	diners-club-international
58	cgrcic1l	$2a$04$UyLnyO3KU3hlIFSxthmTyetLfZ7Zfh4B8kXc4dQ6MJ3Gsfu9Zbyia	Cindelyn	Grcic	916 Lillian Lane	plamy1l@ihg.com	mastercard
59	ebenton1m	$2a$04$7toXXAhTUoKuqKQaSJ8Spu2IY3t4ERYEqoDpcJINJ8iZYbHMxnpWK	Eadith	Benton	64 Sachs Drive	tfreathy1m@123-reg.co.uk	diners-club-carte-blanche
60	stuftin1n	$2a$04$VCqmHpTplUNrEyaXpFobze/6AR2XwtxAUkSXjFTa4vdRHGeG3sO9a	Skylar	Tuftin	51 Manitowish Terrace	bmarson1n@miibeian.gov.cn	jcb
61	mwilson1o	$2a$04$b9G3D6rdUehzWRBSFDtli.kOQaYSN8nYruPfSJlF4yCVMV.SE.0Va	Mathias	Wilson	6 Meadow Valley Trail	mfolkard1o@sbwire.com	jcb
62	hklink1p	$2a$04$8tIxwp5ZhKxuAv6AVk7YlugzqduvPx4mFfHSj9DEFyvoyFDjL/Jf6	Hynda	Klink	16639 Westerfield Road	dwhitten1p@berkeley.edu	switch
63	kgoymer1q	$2a$04$scJzbHc56olmjbgqxxkEse1d1QQcQcYmuHLRb3RsgRMET1Khvfq3u	Kincaid	Goymer	83 Claremont Place	gcano1q@weather.com	americanexpress
64	gharden1r	$2a$04$zbNrkOE.QPAbTAv1CzN2ie2B/7ddKcDXsMy9kk8lU04C/6gXp/5cu	Griff	Harden	96 Manufacturers Crossing	gbinney1r@nsw.gov.au	visa-electron
65	gpetrushka1s	$2a$04$bGbYWIO..I/HY2YQyaAH7O/CP0GbfA2BWwKe3VtuNIpBDpcvS3XX2	Gaspar	Petrushka	24487 Manitowish Junction	klanon1s@tinypic.com	solo
66	hquinby1t	$2a$04$DMtWhCDmJSp7xeKdu0nHB.si2xFvClZGMfv0qlKfQrp4LeOE.hSI2	Hank	Quinby	0 Service Court	jrosario1t@baidu.com	mastercard
67	jcuell1u	$2a$04$pih5toYejtXuf5hrZYypMexMh9kBt2BSa4gqlH.2FJt3PlqTL6Fhe	Johnnie	Cuell	8696 Waubesa Place	ebonnin1u@spotify.com	china-unionpay
68	grobertshaw1v	$2a$04$BUfMZIVIsAktTry.1kaoTeemRLELC0.Cdq1Qj/hkgEuoGPVkGhyQG	Gannie	Robertshaw	2 Bunting Court	pkinnerley1v@google.ru	china-unionpay
69	fmacronald1w	$2a$04$LN8faVkV3gSKYFuhpFdgg.8e7j8NjYfrZ.3RaIr5FZTM5yQTufqFa	Fielding	MacRonald	91232 Sommers Place	gpalffy1w@baidu.com	diners-club-carte-blanche
70	alerwill1x	$2a$04$UNJtK/6vDeqjIXCFuXd2z.j1D7PRAILkp28MFnTVBqBQpg3CuMInm	Andras	Lerwill	939 Susan Way	iwoodbridge1x@oracle.com	jcb
71	jdudderidge1y	$2a$04$koxfnVau7Qy9.tZbXXrEH.htpBstv8pwzSC4a/JWouwUdtVmap1wy	Juanita	Dudderidge	8 Daystar Avenue	mcasely1y@rambler.ru	jcb
72	sdenyagin1z	$2a$04$hhbwscuZnZ9Fltsz8Y2LsOcKTorsBBG/svKqoBVl84SN.BAOq59JK	Scot	Denyagin	6395 Swallow Crossing	igiacubo1z@shareasale.com	mastercard
73	gattaway20	$2a$04$WUXBT91juxVzfP2Rt40rv.ZNAe0fsAz0sptWh7xUKtgbdZ9cjV5B.	Gannon	Attaway	3 Rutledge Trail	aparradye20@smugmug.com	americanexpress
74	lreddan21	$2a$04$D7BqUGAQqkHWbuHpSHHLnej/DmskdNnmJ8gHGA5IlMZt.HK6RDDO6	Lizzie	Reddan	6 Blackbird Terrace	fpinard21@wiley.com	solo
75	ykreber22	$2a$04$HQKx41jDlG8lL/kesxnK4.U5Pwjfht89D36zo6UOLcqD/lpymsRpK	Yancey	Kreber	18528 Bultman Court	bgaddes22@businessinsider.com	diners-club-enroute
76	jeglin23	$2a$04$XHSX5Cqbqm9hVcnzFZYwZ.Hsd7ynxZu2WC7vVy35AXT0IM5ONqLaS	Jabez	Eglin	88 1st Street	mposten23@usnews.com	jcb
77	mkidgell24	$2a$04$Q/qqCCt1GrHRRvD.5gah2eWffm740aYhOAuA/6mALaZK8k0Q3Ny5m	Marja	Kidgell	2561 Coleman Street	mhuscroft24@bloglovin.com	jcb
78	gbuttrick25	$2a$04$/pCfXhnyhkhUtpjvQXC1Mu6FMWyWdYtcr37rZMhHRVwzWw4KJx2li	Ganny	Buttrick	5 Grayhawk Center	dferrie25@google.pl	switch
79	cdionisii26	$2a$04$XX09RtpP.vnf42gZ8rBbx.5OIPBnRkh0SEMQdAVmc9wye5y4Gax/i	Cyndia	Dionisii	90 Cottonwood Hill	khynam26@istockphoto.com	maestro
80	rstraffon27	$2a$04$McN/LZ5Zd2s.FpHxfHFuHuzdAUvjth01aKxmdXbfFcBTMvB8zV0P.	Roxi	Straffon	4 Becker Hill	troad27@umich.edu	bankcard
81	mwindaybank28	$2a$04$BD/AUhKy29sSi0lIZ5eM5OAKXNWhN.gl9xl01U5EEFwQPpJVPO14S	Maude	Windaybank	484 Corry Court	edaws28@nifty.com	mastercard
82	biacobacci29	$2a$04$zag5Fdmv1XCYSk4DcKjYCeDeQQ9OAXNX4LoobL6Q04bWGXl1iZXfC	Brose	Iacobacci	792 Merrick Way	ahatzar29@51.la	jcb
83	myellowlees2a	$2a$04$BZtq1BSvrJlXPbpzFhykOO4vn.zyMVZi7ORKE4VT4unmiCp4FmPZ2	Margaux	Yellowlees	48389 Dawn Street	elaight2a@google.de	americanexpress
84	pdarragon2b	$2a$04$72aK88NHvEGx2GQ1yqRJ9OLoV8HWH5UtikUeN2mYDx/ZtwpIQIIDy	Peyton	Darragon	0670 Independence Alley	swhartonby2b@list-manage.com	maestro
85	rbern2c	$2a$04$O2DjCrD0jDZ6v6FBqBIAYumMd/Az4yKaM5wQkLuUgVhYwhPHXL.wq	Rube	Bern	786 Clemons Street	sragbourn2c@youtube.com	jcb
86	candreoletti2d	$2a$04$yjcFwbFtDs0f0atQMNYUF.TKayz2AYirbDDlknmES79BfVcpd64kW	Chloris	Andreoletti	1 Eggendart Terrace	narne2d@hhs.gov	visa-electron
87	mcirlos2e	$2a$04$ncM0DG6G5atNhag3DicWhOBapvEzvmv/9mWNS7OjshxDF6MnoCUZe	Milka	Cirlos	2 Talisman Parkway	mrounding2e@pinterest.com	visa-electron
88	adunsford2f	$2a$04$Hy3.yJ1lXsGlpqjLDUHvVOqlNWNPkI3.tMXdC8ULfg1jH2eXMx/xu	Adara	Dunsford	31371 Shopko Circle	hpregal2f@trellian.com	maestro
89	acranny2g	$2a$04$NLtNTyUqsYZuB4iOZy8UOeqzBxYoK.n5N1Qkt9V0Om/2/m06Kr.E6	Andriana	Cranny	36729 Hanover Lane	cstocks2g@wix.com	mastercard
90	csustins2h	$2a$04$kp/b78yR8KCqvRlR2MmZPec86lTlwS2srLR0OzfBRy73rYx34mYHa	Camile	Sustins	65715 Vahlen Pass	mlocarno2h@google.com.au	diners-club-carte-blanche
91	lcockman2i	$2a$04$iNbju1Sxttbzhc2aV0.zE.vz7GMNaD5RLcSAxMqCo2qM9e1r5Lmz6	Louella	Cockman	719 Johnson Circle	aballston2i@google.co.jp	jcb
92	hcochern2j	$2a$04$RXVHgCrB4to0XSWHL.ZZ.ukWgiVEWv0zfwVZRGe4LvOIyfoh2HLCS	Holmes	Cochern	830 Reinke Street	mbausor2j@state.gov	visa
93	wplumer2k	$2a$04$uAxTG3ksUaIWVCn3mzmDJOWsvEwxTjyxeX3lsZnM2UkBgAzQwg1zW	Willard	Plumer	62733 Hagan Circle	kantuoni2k@senate.gov	jcb
94	ltattersfield2l	$2a$04$yuVLlEaQdHr7vCiLBHJxSunALtkQZ.7ULY/7bGWXFxAsLsQhXJ.Wi	Linea	Tattersfield	372 Montana Avenue	pdmitrovic2l@163.com	switch
95	ldevine2m	$2a$04$D6x.SCNSjsdBMANGbHkkHOl8cacQnSqmbcU63tvW4HG0ULkY8B9MC	Lin	Devine	17 Talmadge Center	bvitet2m@histats.com	jcb
96	jnias2n	$2a$04$i8WK2zLsG8oafdIIgblr0ujQL5PEFnI/vhzzb2IPhNMjgy0xQcyjq	Jewell	Nias	997 Kim Avenue	cdowning2n@bigcartel.com	americanexpress
97	lnewson2o	$2a$04$CLHNsjXwDFNX3kUvAFmVyuzBV2K9qmreFL.mbqZdYmGa2MF.qq9hS	Laural	Newson	935 Springview Alley	htrueman2o@mapy.cz	mastercard
98	wblackmoor2p	$2a$04$M0wa9xgY/ywvClPCFvOSeuAoevJCch0QKwuKvkkiiglsOeAD9wJ.C	Wheeler	Blackmoor	719 1st Lane	gleighfield2p@wired.com	mastercard
99	brobley2q	$2a$04$7qILRrnzvJ7VVKjY/7JbdemVMxuoAkJmAaJE/RwhD5hgH/AbRP6Ky	Betta	Robley	779 Rigney Alley	feveriss2q@reddit.com	jcb
100	hgolden2r	$2a$04$om9gjTmPv/sNcm/Ul07PnecqeIRAXM2sTmSem7NqUxezKs0Q7J2hu	Horatius	Golden	83 Sauthoff Court	phighton2r@rediff.com	visa-electron
101	jkoche2s	$2a$04$55akvtwVtl91SzX.dMzhquqVMORSI/q3fRcrsBs1vEG3rwKD7ampy	Janos	Koche	44 Sherman Hill	cmacrierie2s@who.int	jcb
102	fcrate2t	$2a$04$7dcmSQTijqydelWLAbczM.8txmDeKjWm9dRzbq3CL4eLXob7kgFFy	Floris	Crate	6 Hanson Point	mgulland2t@barnesandnoble.com	visa-electron
103	garrell2u	$2a$04$ixKrTx9iPn61cRocyVIIBe0fffk7JGJ78eDWNMvbhk.mPbs4HPM0S	Gnni	Arrell	5 Vidon Junction	ckunes2u@webs.com	diners-club-carte-blanche
104	eblaxeland2v	$2a$04$nyYd38Epf8dm9yYmuRVuV.7SzPXi0svLjwGfrPcGfhiQsJ1wVFss6	Emilee	Blaxeland	035 Summit Park	ljancar2v@ed.gov	jcb
105	sgraveson2w	$2a$04$DbasLS76g3jaAUNgtQnnTu9sJpNhrsXXVZGAIHT5hQnJtzYc8/25e	Siobhan	Graveson	859 Vahlen Lane	cblinco2w@yellowpages.com	jcb
106	wsaxton2x	$2a$04$8vR1H/dXKinAeQzJq0ZdpO70y/yfqZNrXGOwStv.6GvQI7i4WnFfS	Wheeler	Saxton	5 Lillian Circle	hswitzer2x@dailymotion.com	jcb
107	vcopcote2y	$2a$04$YleAJGP0e6BIr6x3P5ZGM.t2lpB6wk/W0dPQdVUf9AaKyj3RBeVjO	Valerye	Copcote	240 Golf Course Avenue	arudman2y@smugmug.com	jcb
108	jgibbett2z	$2a$04$dLcUNDVcDGgBrry5uItumups0jcXRMgMar8Ix.pQUugkI.GSkniky	Jacenta	Gibbett	775 5th Crossing	ecristoforo2z@mlb.com	maestro
109	cplaunch30	$2a$04$rYTZi67PkgZjwAKH.oM2D.4Ebef2BDWZqxfbkKl4MhBUx2G.PdME2	Candida	Plaunch	86028 Butternut Avenue	ntesto30@yelp.com	jcb
110	apenna31	$2a$04$P.L9A9sWj1UFy88AowbbeOp4nWZ9Qg6ewRvo/.lUsQTrbNlUwqbI6	Ardeen	Penna	43 Nelson Point	aheckney31@sourceforge.net	jcb
111	gscouse32	$2a$04$4u8I.3pmatolYhg/5JPkAeby91R2ROHwOx98gu5Kz4HJ1ayfHfV/u	Gustavus	Scouse	7 Dennis Drive	ehablet32@amazon.co.jp	china-unionpay
112	dmatfin33	$2a$04$fq00luJIRuhhEobIRsM7f.1smt8rsP0Nj2igBtITDxqIsiLMU3xb2	Diarmid	Matfin	5 Moose Point	bpaxeford33@mapy.cz	switch
113	emarfield34	$2a$04$7iyqjPDT6EENug7ZCQumfef4e/v8l7DsliUaaK3vXIU2s/vgeem1.	Enid	Marfield	2 Brentwood Drive	lpoltun34@illinois.edu	jcb
114	mandryszczak35	$2a$04$2mwFAhNTQezX1FtSuWNVs.JGkBjUW9AhmCjN6mBkIThuKbWDt/pk6	Maria	Andryszczak	999 Harper Terrace	bphebee35@marriott.com	visa
115	tcardillo36	$2a$04$w04IozzyuKvkulVQDlt7yeGVfRtZpyHuqRAQOTVvSArjgrmlrpRfi	Tybi	Cardillo	0327 Vidon Lane	fgodlee36@ucsd.edu	jcb
116	lshropshire37	$2a$04$A5gX4aq4R1CD5LISX90wt.lNHLlfQVeLH06iUmAJtBBYITePhh156	Lauritz	Shropshire	112 Dottie Terrace	ppadfield37@guardian.co.uk	jcb
117	gswinburn38	$2a$04$BfECO2erxxEYlNUa4wcmK.nlykXoTrIOIVz79m.2q5iMHX4K5B.Tm	Goddard	Swinburn	3141 Sunfield Road	ksangar38@huffingtonpost.com	maestro
118	ppaumier39	$2a$04$/rzdtbdoqt.DQWKTKyTtN.1myiyMxg194IJZPWSHItvg09.mmy/hu	Pammie	Paumier	23 Sutherland Pass	wjandl39@domainmarket.com	jcb
119	dblackmore3a	$2a$04$TIq9TYz7JBgt0lguYVMt1Oz.5XesaL6NNb/bNgk3/WhOfi/m7OKNa	Danell	Blackmore	2 Bartillon Terrace	jgreson3a@forbes.com	instapayment
120	asilber3b	$2a$04$BijjW3m0giWvOmzTbi0T8.BWFgJNuQ3TGZiHRjNo/46zwxrGidh3u	Audy	Silber	857 Express Way	kmcfade3b@ucoz.ru	china-unionpay
121	mbutteris3c	$2a$04$LbT3RJgWzF/xqbnqRTgKeOEwHHxUyrtnmxcqkkmwsGGC0j7FmY7wW	Morena	Butteris	17550 Mifflin Plaza	galywen3c@china.com.cn	diners-club-enroute
122	akarlicek3d	$2a$04$IJwuPODjMsrHTr5MPgxwEeWLFV8qujPPVoO3F86JqWipRtmpFxJAG	Ardath	Karlicek	196 Katie Terrace	mwaters3d@blogspot.com	visa-electron
123	fmilborn3e	$2a$04$lSTRpq1c/0fm7xLP4wtaU.2qqmrrSt/TBRDV.uAW/t5A4O88PuFXS	Fabio	Milborn	53125 Utah Street	tbayman3e@woothemes.com	jcb
124	kgalier3f	$2a$04$9IG74a/6jIQ1TAyIZFFua./U6Fps.bjfubEGO8dYou5V4RJzQ0Xd6	Kailey	Galier	4613 Myrtle Circle	mgiacomuzzo3f@discovery.com	maestro
125	tworley3g	$2a$04$MaxVbOwwcsIKman8KMJL9Okr4ugbf18g1RxvEBIWlQrnY451cxr9S	Tobi	Worley	54318 Summit Court	rsiward3g@slashdot.org	visa-electron
126	dstaniforth3h	$2a$04$a8ueB9hEAqOtzYkAExBt..y2eqEDJEFDcDOYeTXxpnYsFBsCHl/GW	Dyanna	Staniforth	37 Monument Avenue	eandrey3h@php.net	jcb
127	dosburn3i	$2a$04$r3AUiXtvS0C3b9s6.2oTlOx4RitWOwB8E0W.a8jbJheCt.w3yoFFW	Dieter	Osburn	412 Sommers Hill	msnyder3i@amazon.co.jp	jcb
128	kprin3j	$2a$04$Wji60lT96Gptvim78bxgVuuuCmROxoxppo.3C4DwOJjsHU0DDC2eO	Korey	Prin	42830 Northfield Center	nsamways3j@is.gd	bankcard
129	lpancast3k	$2a$04$qWkKtUPw41SC8cy0QEuUlOurQp5GcFiAaQaIeCb.rbjtvH6DEsc4O	Letizia	Pancast	641 Hanover Road	mfydo3k@weather.com	switch
130	lcuthill3l	$2a$04$gFGmvmj99GgHllTr6e0wguRX8Zao2TshT3gFQvvyeLAoJwuZS4kU.	Lazarus	Cuthill	19985 Oneill Junction	aharesign3l@dailymotion.com	diners-club-us-ca
131	wnann3m	$2a$04$b1i1D1onhlvOJIXPhC4reOw1QtaVYvGUPIHPtJ1fBA9ed57qB.4dy	Wenona	Nann	2 7th Alley	jfaucett3m@behance.net	bankcard
132	hlamke3n	$2a$04$/NVLoS.P7UGCUgCsxSSm2Oz3ndnx5YohROkRcsIi0LnGGldUyVLzG	Hunfredo	Lamke	245 Spaight Trail	tdenington3n@wsj.com	jcb
133	mlatter3o	$2a$04$3SOr4NMyRUAbkVA.S7n6lewrvsohFmzETI/9mDIorpQfAj479BMpO	Merrel	Latter	6262 Mesta Crossing	gbashford3o@jalbum.net	jcb
134	myurkevich3p	$2a$04$qJ0Oxe2uoAEtWcsHqzyS0uPINWFwy3cCAm8jrWLIeRVEPTv0imKY2	Mame	Yurkevich	97852 Sachtjen Point	mtidridge3p@opensource.org	jcb
135	wkermott3q	$2a$04$TjlvVrzf3YzyZ/V3trHNuuP8aJ507L4OnFglQomcjXjY7.B/e7Ipm	Wallache	Kermott	24764 Gulseth Court	gwilkes3q@odnoklassniki.ru	jcb
136	dmcclymont3r	$2a$04$nTT9D865Sys7fd76pZdh5.KtXr1tZYa3TCW1kCXmHRWtQrdVMDxw6	Daryl	McClymont	0476 2nd Way	zvader3r@alexa.com	jcb
137	rbrasseur3s	$2a$04$FmL5CF8MkDHrlU7lSruTiunTRGBCpSaiBvSehJ0q1tVlb2qGtu.Re	Raffarty	Brasseur	26 Raven Avenue	tlowbridge3s@blogger.com	jcb
138	shallick3t	$2a$04$TnSAzBac98XP7irNz2QXd.PEKpxM3heu9PHsHEXQuhdcU896lHl3e	Sumner	Hallick	3135 Novick Center	vwelch3t@tripod.com	jcb
139	idiruggero3u	$2a$04$yPVUqA/C7Y5T2M750TCWoO78.a6glecfumfaai7qsbFoXY0ACapdi	Isidor	Di Ruggero	33 Graedel Court	jgrishanov3u@discovery.com	solo
140	sknightley3v	$2a$04$yGTXSVl3WSjX111BVHI1v.7Gh79NZ9z5NJ9NaCBqI1iKQHMB706lC	Stavros	Knightley	2116 Fair Oaks Terrace	lingerson3v@goo.ne.jp	diners-club-enroute
141	vlemerchant3w	$2a$04$hkLYJJVK5CnPnOW0viJr1O4T7NmPx9u4Hm.ofhWOxsFlYK.OBMjo6	Velvet	Le Merchant	64 Hovde Circle	mcasini3w@elegantthemes.com	jcb
142	jfearick3x	$2a$04$DbXWo5kMEW/4b.UvMFjGVO4XNG5tRe5N3BbjQ5.RPHAl0nMW5YBLy	Jarret	Fearick	196 Bashford Circle	chuckerbe3x@cdc.gov	jcb
143	lcarabine3y	$2a$04$lrj7qKsqJHuXps2dTcZsE.uWldBX.DuVzv0teE5d.QvN6Hfuj7vhG	Lennie	Carabine	6 Northview Point	jcleft3y@is.gd	visa
144	cbenza3z	$2a$04$s6QmDRPYXvv0syllOZEK7u4p6tN9k42Bzo4HixFHVhfi9Bb2LJvjS	Clive	Benza	123 1st Drive	socarran3z@samsung.com	laser
145	hcherrington40	$2a$04$WQTRGxzbLbBbXs8G2/YYhuuZOEbx3LAcx7jOaDtpbgv9GiF9i4FCe	Hodge	Cherrington	2571 Kings Center	rsheals40@google.ru	diners-club-enroute
146	jellesworth41	$2a$04$4D69DtHjpcBt1OsIhVIgAeB36jtksmAgeV1AjffAp2Qwb5izOSZIe	Jarret	Ellesworth	1708 Lotheville Center	scahen41@tamu.edu	maestro
147	clang42	$2a$04$zlK1/eBx7p.SFyeVgmydTOuFzi9TslVYBzkgVxsJdwFUv7cs8WeOa	Calhoun	Lang	26 Lakewood Gardens Court	dsandhill42@amazon.de	switch
148	hcamellini43	$2a$04$nBQZgFzSyvTulEwElItmM.6Wl0tDqCAudbaKXAO7o.AOT9mrwLQ52	Harriot	Camellini	6 Eggendart Circle	jalban43@home.pl	diners-club-enroute
149	jhamber44	$2a$04$r5zPS2nmCZA267216Y8H9eUeeXyY4ek2ESlSgp2OoHR8AyxaDe8ae	Jessi	Hamber	4691 School Terrace	bstenners44@hp.com	jcb
150	bzoren45	$2a$04$pvaF9DIloU/Ejg0CNMV8n.UOoR.IJdXHrZFLTg.QCmNEMhfxvFlge	Brinna	Zoren	534 Division Trail	ctomaselli45@shinystat.com	jcb
151	dthorneley46	$2a$04$Ge0UURu42wpMuWxA8SNc7uwFdFR5hljWogTXPovUoXHJDr.kfK662	Dorotea	Thorneley	96 Bonner Pass	acardenas46@opera.com	instapayment
152	ecastro47	$2a$04$iXPaw9z8Meoc5Fgh3Zfvf.KPYCq1/pouHivNR0VQ6T12qlbzFsiAa	Ethelred	Castro	83639 Jana Crossing	olages47@craigslist.org	switch
153	rgradwell48	$2a$04$FN5KvfVxdOdZgf1OlRUCLe8/rvNVDka4MMBZyCijcKgInW92jsGfS	Randee	Gradwell	77 Vermont Trail	tlisimore48@deliciousdays.com	visa
154	frobjohns49	$2a$04$.sKE9Rnw3ne/sejoL4pyKO0TLnXIve/WmpZaWkM3NEEutnMLYSedi	Fionnula	Robjohns	0 Debra Avenue	shazeldene49@discovery.com	jcb
155	ltolomelli4a	$2a$04$1lkL7/hypAHBbuL8gNshNOkQhZE6C9YUGBE3ZUuiXzcN1Y3LYaQ8u	Lola	Tolomelli	624 Golf Course Trail	dgoalby4a@exblog.jp	bankcard
156	dmcevilly4b	$2a$04$hVlVWxTmmAIvfh9dATBMTuAqZGT18XjkEIXzV8gMJRoQJ/OpD/BgK	Dion	McEvilly	799 Larry Alley	cgroomebridge4b@harvard.edu	jcb
157	broddan4c	$2a$04$uPAs3hIW0RizjJbSGcKFcupIS2HBWOTCDAWJYqOZnE9/1u7w2z2Si	Babette	Roddan	002 Rigney Place	jbrydon4c@trellian.com	jcb
158	kforo4d	$2a$04$WB5UJqX4ZwOgRko2kr1paeHaG2IYnPpACmyqxkMGjlpt1qJLeaNz6	Koren	Foro	03893 Dixon Crossing	soleszkiewicz4d@seesaa.net	jcb
159	ncamacke4e	$2a$04$fHnBJ6VaQvH55VEQobd8qekqY55LTl0dPUI2eWrpeOWRZaPEkblLu	Nefen	Camacke	4 Vermont Trail	dshovelin4e@goodreads.com	jcb
160	bkarlicek4f	$2a$04$d2nOClXX7PbdoMkkbXwGkO5h/RS21aDnlVmdWw9mrdWVoOP/RZKli	Brendis	Karlicek	4 Raven Lane	fmccrory4f@51.la	jcb
161	wjeffree4g	$2a$04$AY65IB2oYPsxqYv.TG62PeBf11oBO5XTy8MNydrhQGPKIrEunp4mu	Wayland	Jeffree	46 Hanson Point	nbartocci4g@zdnet.com	visa-electron
162	ibittlestone4h	$2a$04$z4d67MW0ms1jN/3q2ihbUer4WBOQmS1wB3KCEbvguq3hVPrUD0St.	Idell	Bittlestone	84 Express Pass	wantonioni4h@amazon.co.jp	jcb
163	mleglise4i	$2a$04$4ti14h40/ZVyQzDGAP5BFuuaPyVWN4gL4CMU/rFZvf961RNUrroMO	Melissa	Leglise	43 Basil Alley	cfuster4i@hao123.com	bankcard
164	svolante4j	$2a$04$VliyXdOYcqjayrdxrV3cJu7LS0HMmGJUDsGK6wW1IFjK7U2kFRl7.	Saloma	Volante	101 Gateway Circle	kpolon4j@myspace.com	jcb
165	lulrik4k	$2a$04$/Q6gYv6TyutYpA2hPzw38OwxA0SEHgaQbkbA7kuWPcjKZ3oUC5Y1y	Lisette	Ulrik	1373 Oakridge Park	htrattles4k@usnews.com	americanexpress
166	ksultana4l	$2a$04$l43jGp0TJ/esW7s3/G7eKOzlRdbMP/.VrgLZ2hxkShKzBw4vbQUBq	Kathi	Sultana	6005 Meadow Valley Place	smckearnen4l@japanpost.jp	diners-club-enroute
167	apaler4m	$2a$04$zejnRH6wFGth7KHM481jrORj/m4LFB2PodBR1hZKmLqnbHtXWK/P6	Andreas	Paler	394 Ronald Regan Alley	lminchinton4m@ted.com	jcb
168	awysome4n	$2a$04$j/TE3YnURdmWbef77FtwEOfWyoG7F/UT/1n2f2qekPrxb6gLmc65K	Atlante	Wysome	1 Derek Place	rbenterman4n@upenn.edu	diners-club-us-ca
169	fitzakson4o	$2a$04$MWTr2fr2mBbUjMzjWEDLveva02tAO/adp25KVz7M85CsnIUe7c7.G	Fowler	Itzakson	71544 Esch Junction	lpavlasek4o@taobao.com	jcb
170	alincke4p	$2a$04$ypRCTUO8AkHSzS83uNxJFuCdwuYxwStOoZHQktaFOS8H2FluS0pX6	Alvin	Lincke	9085 Buell Junction	jwegenen4p@tiny.cc	jcb
171	mbrudenell4q	$2a$04$fFWRASjs8qG.EPPZodQoR.kZZWgPNFKBl6dC3mKMP88WZMz8Zw/Ua	Morganica	Brudenell	35354 Veith Plaza	mkempstone4q@sciencedaily.com	china-unionpay
172	qharrild4r	$2a$04$9bugohbR3y8gp3Rfvskx4uPvJ//mdjHHi8x7AAkpFsCRFjvzcPwiO	Quillan	Harrild	5195 John Wall Point	bgrodden4r@indiatimes.com	jcb
173	haronov4s	$2a$04$GWQWvruTqsmi2nBkga7EbeiXj238/zRLCRHhntTC2r3wqgAp.HEJm	Helenka	Aronov	0946 Northridge Avenue	sjepson4s@unesco.org	maestro
174	tcumberbatch4t	$2a$04$lST9UIoDUBAwYx8UT8z.AOK.s5TjXw.epojbGHbxMba7t3xyu/tJy	Todd	Cumberbatch	1689 Kings Lane	rfalck4t@senate.gov	jcb
175	ibleakley4u	$2a$04$3cW6k6KSuFpvjZUYsWy5gupai5YgMje0Ik658K.ozwk35CUCWcqci	Ivett	Bleakley	7 Schurz Avenue	mlaxe4u@hexun.com	visa-electron
176	ekinder4v	$2a$04$3FA.fyJWP0Gqq8tUMvgPxOSsaMyoLHuF2FUQ3j6Nhzpv74jZ//hFC	Emogene	Kinder	1296 Merrick Point	rupfold4v@artisteer.com	instapayment
177	epudner4w	$2a$04$.fIkPzTpM4j4ogz9QwJPEumVgP8dbUdWx.iw1FgRlgSMCvb7LLOxG	Estele	Pudner	28719 Myrtle Terrace	chanks4w@uiuc.edu	jcb
178	agilfoy4x	$2a$04$vQdeU7kxRRQ/GcgKIvdhnuHDiebPFKPCkz55ZnlbcJoSt4dvsTrBC	Aldin	Gilfoy	51038 Bellgrove Road	tdechelette4x@deviantart.com	laser
179	pmoulds4y	$2a$04$XYikHvE5/c5lhVvvJDV2n.Aus/xP5VXSsbFMePwWZuOp/DqzOShsS	Prentice	Moulds	56741 Holy Cross Lane	blilywhite4y@icio.us	diners-club-enroute
180	sgowrich4z	$2a$04$dzcM50U3ASbmV.ZsyJOq0O/9Wq6FwhjrjvYyqtdo.ZPPklmP7Pane	Siffre	Gowrich	4849 Twin Pines Drive	jfennelly4z@cyberchimps.com	diners-club-us-ca
181	cstrettell50	$2a$04$YZ1NmARcoJYvttCcemSCc.LB1B303CDKetOC4FGZql2gkpsOsKHL2	Cariotta	Strettell	5257 Armistice Plaza	dwhelband50@i2i.jp	diners-club-carte-blanche
182	myurenev51	$2a$04$4UcR2jZttCNhjhZWDtQkMezfybPTFBidXMH6pC6e/0ar1MRpodX7O	Morgan	Yurenev	726 Luster Court	chaily51@infoseek.co.jp	visa-electron
183	cminguet52	$2a$04$GnyWdaTOcqgai633C2TMJeALA9RPU0jAyHNUCAjhJgaVqNN.RvwPi	Conant	Minguet	8544 Pine View Plaza	cneeves52@cargocollective.com	jcb
184	hcoughlan53	$2a$04$NcpdHLCjjNf.GzTZ3WyPZ.zGEkxOeHI6uRrrtDd0lfQTQ.XrV.fWK	Hugues	Coughlan	9425 Atwood Street	istanlick53@cam.ac.uk	china-unionpay
185	gisoldi54	$2a$04$e2a.gvMkmPhscAQ1YO0VeeANOYiH16PZp3TBpHVlF8x4ZqL5DMa7C	Gabbie	Isoldi	945 Westerfield Point	gwhittaker54@youku.com	maestro
186	vviollet55	$2a$04$jlBIqbzoOjfgaJIaVdNjQe8EfCTeVwuVllCmWXhkPOMHZkga2zSoq	Vaughn	Viollet	63 4th Center	tmeadway55@mozilla.org	jcb
187	dnutting56	$2a$04$3J2wYrXChIc5HW4kkHu7h.CDlqyHL9hiIUvL.5SuDB70XWy4RijHK	Davidde	Nutting	4236 Bowman Pass	mjeune56@yahoo.com	jcb
188	vwiggett57	$2a$04$RnCb3VkImimIR2hej0FiEeNvLNlgUSzN.x/U53bfbV0NuJU5QEkAC	Vivienne	Wiggett	94 Toban Center	mbetty57@zimbio.com	jcb
189	epaulon58	$2a$04$e6hqI0KNkEBU6AIUMSczNuXAzOI0HCnO.zJ5VMdO7E9lXs/IVnI7C	Elysee	Paulon	7380 Washington Alley	bheineking58@cdc.gov	mastercard
190	yjanu59	$2a$04$26W.CgFj7k9kKHRG51QoNekLluT9jDavR/PZpQU2F.HYnUQSE3bEq	Yasmin	Janu	4 Daystar Hill	mdawidowsky59@sourceforge.net	jcb
191	ymckeevers5a	$2a$04$L7HdzfUISDhzuMLfVo1GmORhZ4jZPFeitSyrQ6lgmFOhbWnNACogW	Yoko	McKeevers	6382 Little Fleur Terrace	cdavitt5a@senate.gov	switch
192	vphilpotts5b	$2a$04$BtZdhmCdspkLEngYViQuX..h3pF4WgIgY03iD85P8FS.GThYJ1EpK	Vite	Philpotts	55 Old Shore Circle	nminchindon5b@dmoz.org	jcb
193	ssmither5c	$2a$04$.jDAbqR/p7XK44aulyo6iOAZih4HNUzYeWySaSXxRJbFRq9P1.hVO	Shepherd	Smither	95446 Talmadge Drive	ncaddan5c@barnesandnoble.com	visa
194	lluby5d	$2a$04$L1hMl7MuXmhskcOeaYnZeuqD8OIE7rzvatPkvjW6Ih3dwxu5a0MxO	Lizzy	Luby	37644 Rigney Pass	brieflin5d@stanford.edu	jcb
195	pcluley5e	$2a$04$dnuwQT8ibaPgWNo6fsEV4e3QUMvVNnC/zsPTlSiZDVbn.23CP33hG	Phillipe	Cluley	78111 Ridgeview Place	jwhales5e@parallels.com	jcb
196	ecoslett5f	$2a$04$aDuH4yYveJkbyKlqFnCn8eRxjhnWftpsN3JiH.RnU13knpOon1Aya	Emelda	Coslett	650 Autumn Leaf Lane	apeye5f@dailymotion.com	china-unionpay
197	fbrobeck5g	$2a$04$bl0xuze3jC3KJ2027EYtXen8cKPQ632udIIJOwvNkSkWj3gVH5uUu	Fidela	Brobeck	47721 Muir Circle	dclears5g@boston.com	maestro
198	ziacovino5h	$2a$04$4Ak7Pa7C9VYRNrbUWyqWw.7VHwjzJtvMLzC7S8RI/IDG.ZXktKU56	Zeke	Iacovino	2 Luster Terrace	nogeaney5h@twitpic.com	jcb
199	rargo5i	$2a$04$d0GLjDugtp/z2ERcPwzmieZLQVPO8wqkIwDOttKPyPTJK.dwgtuve	Rollo	Argo	6 Barnett Hill	cbilyard5i@twitpic.com	mastercard
200	kjurca5j	$2a$04$cH4Qb9XxTeJAabLmNeeBLeQT7fYZ066YCbhsXWyuY5CwvnI5S40a6	Keri	Jurca	435 Oriole Street	ncage5j@java.com	mastercard
\.


--
-- TOC entry 2889 (class 0 OID 16402)
-- Dependencies: 201
-- Data for Name: customer_order; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.customer_order (id, customer_id, product_id, quantity, price, currency) FROM stdin;
1	128	9	53	316.89	EUR
2	56	183	56	423.01	EUR
3	11	10	26	459.74	EUR
4	45	181	51	136.14	EUR
5	98	67	8	25.18	EUR
6	116	27	96	222.80	EUR
7	43	162	22	608.79	EUR
8	176	109	32	432.86	EUR
9	119	112	30	386.17	EUR
10	185	120	24	469.94	EUR
11	99	59	50	746.69	EUR
12	43	128	14	364.39	EUR
13	78	115	29	180.25	EUR
14	48	85	88	279.86	EUR
15	187	48	6	565.35	EUR
16	94	67	10	798.86	EUR
17	80	178	14	322.27	EUR
18	106	117	2	777.32	EUR
19	109	81	51	434.25	EUR
20	93	165	50	676.64	EUR
21	169	22	57	534.41	EUR
22	40	182	81	554.70	EUR
23	133	120	57	7.12	EUR
24	46	36	66	239.94	EUR
25	90	4	29	158.75	EUR
26	126	150	90	268.07	EUR
27	110	131	4	785.59	EUR
28	195	9	95	311.46	EUR
29	178	80	76	586.76	EUR
30	39	140	34	246.26	EUR
31	192	73	99	609.09	EUR
32	107	77	14	583.32	EUR
33	95	121	14	34.30	EUR
34	15	104	17	664.74	EUR
35	114	133	86	7.86	EUR
36	117	49	98	558.78	EUR
37	85	101	61	436.07	EUR
38	183	156	54	219.26	EUR
39	37	129	1	656.89	EUR
40	183	175	63	74.31	EUR
41	20	42	41	781.53	EUR
42	198	173	74	232.19	EUR
43	102	44	8	192.48	EUR
44	5	36	18	475.41	EUR
45	139	63	68	48.09	EUR
46	122	33	54	685.88	EUR
47	159	161	19	675.15	EUR
48	36	136	72	258.81	EUR
49	1	61	11	498.82	EUR
50	8	198	57	125.46	EUR
51	132	128	78	209.36	EUR
52	148	164	36	555.50	EUR
53	3	113	91	529.71	EUR
54	137	154	10	676.33	EUR
55	185	197	67	618.35	EUR
56	112	62	26	493.19	EUR
57	7	154	17	523.60	EUR
58	11	122	27	579.33	EUR
59	116	81	78	65.55	EUR
60	177	110	33	529.65	EUR
61	8	84	81	484.02	EUR
62	1	144	91	558.45	EUR
63	23	41	66	7.82	EUR
64	128	143	90	49.24	EUR
65	25	166	11	777.82	EUR
66	87	165	59	405.35	EUR
67	87	157	81	30.63	EUR
68	110	165	25	231.53	EUR
69	107	84	47	29.95	EUR
70	45	45	90	452.93	EUR
71	85	78	18	51.36	EUR
72	143	104	9	735.67	EUR
73	162	99	65	434.15	EUR
74	58	17	62	174.65	EUR
75	186	8	8	309.65	EUR
76	114	147	44	389.14	EUR
77	178	106	35	291.53	EUR
78	84	12	64	738.23	EUR
79	112	36	60	71.66	EUR
80	102	181	8	153.29	EUR
81	31	118	84	90.99	EUR
82	42	13	41	319.39	EUR
83	52	140	9	343.32	EUR
84	81	10	7	633.85	EUR
85	177	45	91	301.37	EUR
86	12	160	84	157.78	EUR
87	64	170	55	585.36	EUR
88	116	117	18	481.46	EUR
89	8	75	73	596.56	EUR
90	57	61	16	243.69	EUR
91	173	11	96	694.15	EUR
92	156	55	2	61.01	EUR
93	29	130	59	238.44	EUR
94	32	2	42	750.96	EUR
95	38	136	78	116.39	EUR
96	101	178	21	704.27	EUR
97	149	29	23	330.51	EUR
98	161	84	14	227.41	EUR
99	143	115	92	89.24	EUR
100	94	167	37	735.41	EUR
101	186	74	70	785.89	EUR
102	43	116	44	183.07	EUR
103	69	132	60	110.79	EUR
104	91	191	74	111.67	EUR
105	55	39	8	105.22	EUR
106	30	75	18	467.24	EUR
107	158	73	66	21.08	EUR
108	165	176	59	763.12	EUR
109	177	77	60	157.59	EUR
110	14	117	28	796.30	EUR
111	159	139	89	252.87	EUR
112	134	155	93	54.70	EUR
113	54	33	8	457.42	EUR
114	186	192	74	305.24	EUR
115	84	3	92	611.15	EUR
116	155	37	50	129.87	EUR
117	156	115	73	628.01	EUR
118	57	83	15	594.56	EUR
119	83	34	30	384.91	EUR
120	23	108	61	681.15	EUR
121	115	123	89	477.96	EUR
122	12	152	46	515.26	EUR
123	145	118	21	723.51	EUR
124	140	123	88	28.48	EUR
125	185	177	17	270.86	EUR
126	42	3	42	323.50	EUR
127	69	123	70	213.92	EUR
128	185	154	81	1.02	EUR
129	121	59	77	188.30	EUR
130	41	180	41	352.30	EUR
131	16	90	74	32.56	EUR
132	9	52	50	54.94	EUR
133	77	49	79	297.23	EUR
134	22	66	98	733.17	EUR
135	60	93	34	236.31	EUR
136	28	63	38	251.20	EUR
137	128	163	69	565.44	EUR
138	91	164	9	21.78	EUR
139	167	1	24	3.72	EUR
140	36	11	54	772.36	EUR
141	188	145	61	252.71	EUR
142	185	183	35	144.98	EUR
143	9	163	45	755.66	EUR
144	108	127	44	291.15	EUR
145	125	120	91	612.02	EUR
146	115	48	5	434.17	EUR
147	47	27	35	244.74	EUR
148	69	194	68	729.71	EUR
149	68	189	4	369.61	EUR
150	88	165	60	112.86	EUR
151	184	132	56	262.25	EUR
152	28	42	19	226.22	EUR
153	146	80	73	422.43	EUR
154	157	33	5	457.20	EUR
155	49	145	65	793.46	EUR
156	45	8	12	94.44	EUR
157	182	102	41	70.87	EUR
158	22	48	56	2.95	EUR
159	77	107	20	450.68	EUR
160	60	170	2	743.12	EUR
161	97	11	37	51.19	EUR
162	66	64	48	94.56	EUR
163	10	174	5	509.14	EUR
164	110	148	98	284.49	EUR
165	59	130	32	540.80	EUR
166	94	41	90	396.99	EUR
167	30	166	75	794.29	EUR
168	87	171	91	797.04	EUR
169	59	46	18	144.14	EUR
170	170	148	21	64.10	EUR
171	57	49	82	194.61	EUR
172	143	162	79	321.88	EUR
173	112	66	70	478.28	EUR
174	29	52	69	98.01	EUR
175	126	1	82	210.83	EUR
176	150	177	98	184.45	EUR
177	6	121	91	53.81	EUR
178	96	122	74	170.25	EUR
179	135	163	61	282.31	EUR
180	77	60	66	708.66	EUR
181	193	143	88	364.21	EUR
182	15	87	2	736.62	EUR
183	167	40	9	656.41	EUR
184	58	139	22	297.62	EUR
185	112	27	91	113.61	EUR
186	45	139	13	320.67	EUR
187	39	176	11	182.25	EUR
188	83	90	12	72.44	EUR
189	97	71	5	569.64	EUR
190	112	142	30	585.40	EUR
191	92	137	13	613.70	EUR
192	17	36	12	324.04	EUR
193	2	188	8	456.54	EUR
194	112	139	10	344.58	EUR
195	44	176	97	408.42	EUR
196	80	134	8	521.68	EUR
197	84	72	80	660.94	EUR
198	131	63	8	180.23	EUR
199	131	194	95	135.51	EUR
200	100	22	66	619.19	EUR
201	49	105	22	309.29	EUR
202	105	12	89	657.05	EUR
203	72	36	70	151.48	EUR
204	6	70	81	436.11	EUR
205	186	193	37	449.55	EUR
206	90	91	93	298.01	EUR
207	111	136	27	683.51	EUR
208	194	180	41	573.54	EUR
209	161	151	71	680.37	EUR
210	76	92	89	730.26	EUR
211	88	102	59	185.13	EUR
212	87	150	96	567.89	EUR
213	137	21	27	200.40	EUR
214	91	197	26	647.37	EUR
215	54	170	68	210.88	EUR
216	129	200	75	88.67	EUR
217	194	21	66	474.90	EUR
218	187	178	50	542.35	EUR
219	125	146	58	376.85	EUR
220	55	66	86	475.04	EUR
221	30	54	11	394.20	EUR
222	178	98	23	704.89	EUR
223	123	94	36	510.65	EUR
224	107	3	88	500.83	EUR
225	122	187	83	364.11	EUR
226	175	153	91	42.82	EUR
227	137	185	89	701.36	EUR
228	164	9	31	649.85	EUR
229	177	140	44	735.37	EUR
230	122	105	48	58.40	EUR
231	129	18	66	292.41	EUR
232	116	142	49	413.84	EUR
233	171	160	32	539.41	EUR
234	92	115	30	14.81	EUR
235	138	46	34	48.88	EUR
236	71	181	56	757.01	EUR
237	35	187	44	5.02	EUR
238	87	113	57	267.42	EUR
239	190	143	96	577.88	EUR
240	66	128	93	306.12	EUR
241	200	200	15	665.06	EUR
242	45	66	34	168.67	EUR
243	126	52	96	522.96	EUR
244	4	10	94	509.82	EUR
245	167	140	44	637.44	EUR
246	81	145	98	207.38	EUR
247	11	62	69	162.08	EUR
248	169	119	79	360.05	EUR
249	156	100	72	761.64	EUR
250	69	23	29	758.15	EUR
251	25	89	24	403.77	EUR
252	150	108	37	370.13	EUR
253	141	123	84	269.65	EUR
254	140	74	95	151.44	EUR
255	118	100	59	481.58	EUR
256	48	127	61	674.79	EUR
257	155	180	80	153.42	EUR
258	168	60	78	795.91	EUR
259	146	120	10	516.47	EUR
260	4	148	46	702.44	EUR
261	9	153	64	462.69	EUR
262	194	50	45	369.57	EUR
263	125	180	18	169.35	EUR
264	133	136	59	715.72	EUR
265	17	176	13	760.24	EUR
266	132	63	2	759.39	EUR
267	72	196	29	214.03	EUR
268	14	86	48	325.96	EUR
269	180	86	49	543.32	EUR
270	42	6	85	126.04	EUR
271	190	159	42	183.77	EUR
272	155	111	90	360.75	EUR
273	55	140	92	688.84	EUR
274	118	198	34	304.18	EUR
275	91	45	89	699.22	EUR
276	16	135	18	386.78	EUR
277	14	105	26	341.45	EUR
278	151	176	51	762.34	EUR
279	124	139	31	443.39	EUR
280	139	152	50	483.58	EUR
281	26	166	8	792.58	EUR
282	44	197	4	353.25	EUR
283	137	125	11	236.88	EUR
284	20	108	74	353.86	EUR
285	195	146	46	797.77	EUR
286	50	189	40	12.72	EUR
287	44	73	59	217.18	EUR
288	49	101	47	520.25	EUR
289	6	141	11	58.11	EUR
290	53	167	65	690.86	EUR
291	55	82	58	12.82	EUR
292	54	121	73	585.07	EUR
293	153	28	32	36.60	EUR
294	63	142	54	185.99	EUR
295	160	119	55	599.49	EUR
296	72	68	9	478.84	EUR
297	71	143	60	678.78	EUR
298	96	58	48	669.78	EUR
299	169	145	21	198.30	EUR
300	170	41	10	617.20	EUR
301	169	196	80	780.79	EUR
302	111	137	82	308.43	EUR
303	193	191	78	309.30	EUR
304	121	1	83	321.79	EUR
305	131	5	59	547.37	EUR
306	111	75	17	551.75	EUR
307	104	191	64	759.76	EUR
308	60	114	38	64.99	EUR
309	90	109	100	693.58	EUR
310	44	200	16	64.66	EUR
311	37	18	59	584.58	EUR
312	185	4	94	543.28	EUR
313	62	61	93	95.39	EUR
314	197	90	13	174.64	EUR
315	48	28	51	136.94	EUR
316	93	59	13	248.80	EUR
317	121	123	93	521.31	EUR
318	187	43	47	769.45	EUR
319	196	18	50	756.21	EUR
320	134	58	13	662.05	EUR
321	177	74	47	610.66	EUR
322	192	53	86	586.27	EUR
323	3	76	51	235.86	EUR
324	52	132	23	240.23	EUR
325	195	54	56	33.91	EUR
326	93	10	73	430.71	EUR
327	102	43	24	15.72	EUR
328	3	162	57	690.80	EUR
329	146	109	51	323.20	EUR
330	10	37	9	361.74	EUR
331	67	197	93	341.83	EUR
332	99	148	10	608.61	EUR
333	85	7	9	88.65	EUR
334	101	85	87	681.50	EUR
335	118	38	91	744.95	EUR
336	112	170	3	209.89	EUR
337	179	105	42	700.14	EUR
338	196	106	43	456.21	EUR
339	23	87	24	532.35	EUR
340	171	7	89	759.40	EUR
341	73	119	16	612.40	EUR
342	89	79	38	285.22	EUR
343	86	132	97	112.41	EUR
344	168	179	69	487.40	EUR
345	37	38	97	503.66	EUR
346	112	47	10	770.40	EUR
347	184	43	24	681.99	EUR
348	144	35	75	409.29	EUR
349	72	5	9	120.47	EUR
350	83	106	46	179.90	EUR
351	179	54	17	520.12	EUR
352	136	14	68	505.02	EUR
353	8	112	50	667.61	EUR
354	179	175	87	485.60	EUR
355	189	187	78	348.38	EUR
356	30	145	51	167.06	EUR
357	150	86	51	223.09	EUR
358	58	151	58	710.73	EUR
359	176	6	24	320.38	EUR
360	113	101	82	724.81	EUR
361	18	170	10	673.00	EUR
362	56	126	68	480.49	EUR
363	106	16	54	267.95	EUR
364	82	17	85	499.60	EUR
365	143	118	84	451.91	EUR
366	32	196	24	687.35	EUR
367	15	182	66	630.88	EUR
368	112	104	91	3.60	EUR
369	3	81	38	340.07	EUR
370	153	51	64	458.93	EUR
371	166	93	27	403.14	EUR
372	113	162	29	675.72	EUR
373	29	159	28	608.13	EUR
374	174	97	66	684.54	EUR
375	133	92	43	624.98	EUR
376	190	195	62	189.85	EUR
377	6	187	69	189.59	EUR
378	70	33	59	528.68	EUR
379	62	34	59	464.95	EUR
380	27	197	67	468.74	EUR
381	133	153	29	84.78	EUR
382	153	120	22	475.77	EUR
383	167	198	60	377.45	EUR
384	181	102	9	268.84	EUR
385	60	37	16	489.44	EUR
386	97	32	92	567.81	EUR
387	39	166	2	169.84	EUR
388	131	25	37	661.98	EUR
389	166	72	75	782.45	EUR
390	138	13	74	681.41	EUR
391	146	171	81	537.89	EUR
392	69	66	32	410.72	EUR
393	98	70	27	530.02	EUR
394	67	96	66	418.38	EUR
395	22	69	22	635.48	EUR
396	112	185	92	461.33	EUR
397	136	41	72	524.69	EUR
398	182	85	90	566.99	EUR
399	102	82	15	505.41	EUR
400	21	129	16	747.20	EUR
401	105	34	40	166.89	EUR
402	114	16	69	44.52	EUR
403	113	65	60	303.14	EUR
404	184	119	15	258.36	EUR
405	90	199	21	758.35	EUR
406	119	138	33	710.62	EUR
407	106	23	2	677.75	EUR
408	13	4	35	741.46	EUR
409	130	64	51	360.38	EUR
410	35	108	52	179.60	EUR
411	3	32	93	643.69	EUR
412	94	112	42	173.35	EUR
413	130	37	92	468.96	EUR
414	186	72	94	178.99	EUR
415	127	191	96	700.12	EUR
416	34	113	48	231.74	EUR
417	68	82	27	779.06	EUR
418	188	58	27	404.15	EUR
419	100	138	87	308.14	EUR
420	153	103	31	276.61	EUR
421	178	182	64	91.17	EUR
422	200	100	5	211.30	EUR
423	114	161	44	155.81	EUR
424	16	185	64	543.44	EUR
425	42	64	17	400.86	EUR
426	163	81	57	450.60	EUR
427	146	140	36	789.28	EUR
428	144	167	27	236.15	EUR
429	148	117	27	208.74	EUR
430	93	14	15	545.11	EUR
431	161	81	61	62.81	EUR
432	168	3	24	45.22	EUR
433	16	15	97	291.53	EUR
434	13	29	54	581.82	EUR
435	45	183	96	513.96	EUR
436	70	78	16	252.19	EUR
437	11	22	41	276.90	EUR
438	131	40	75	449.07	EUR
439	78	142	15	22.50	EUR
440	154	80	72	681.49	EUR
441	170	44	54	656.70	EUR
442	107	27	16	13.70	EUR
443	112	104	27	272.07	EUR
444	172	169	10	261.38	EUR
445	26	64	54	144.59	EUR
446	30	60	56	494.62	EUR
447	154	108	51	308.72	EUR
448	173	56	36	606.71	EUR
449	71	112	90	610.59	EUR
450	172	103	9	446.36	EUR
451	92	91	92	470.15	EUR
452	116	77	15	623.67	EUR
453	67	9	20	611.19	EUR
454	109	81	41	83.14	EUR
455	66	185	13	753.20	EUR
456	152	36	34	76.50	EUR
457	141	13	62	255.69	EUR
458	144	54	86	333.11	EUR
459	140	139	30	86.50	EUR
460	7	147	96	386.42	EUR
461	41	116	31	149.74	EUR
462	91	175	11	225.83	EUR
463	99	188	16	646.15	EUR
464	164	173	58	452.75	EUR
465	94	74	21	643.45	EUR
466	195	195	49	695.06	EUR
467	2	68	91	190.10	EUR
468	154	85	27	785.10	EUR
469	130	76	8	446.50	EUR
470	174	117	35	165.88	EUR
471	93	42	9	362.52	EUR
472	194	52	52	556.28	EUR
473	81	2	21	391.98	EUR
474	54	124	93	310.41	EUR
475	70	52	34	388.72	EUR
476	197	139	77	569.55	EUR
477	119	88	15	735.79	EUR
478	106	80	39	130.05	EUR
479	104	40	43	478.46	EUR
480	21	196	94	712.74	EUR
481	52	45	48	765.61	EUR
482	179	47	100	62.61	EUR
483	122	9	45	503.89	EUR
484	152	173	15	379.81	EUR
485	144	33	76	590.56	EUR
486	153	169	67	18.08	EUR
487	166	17	37	76.58	EUR
488	133	55	20	464.66	EUR
489	37	61	59	325.30	EUR
490	99	179	80	30.68	EUR
491	169	96	37	354.30	EUR
492	21	5	19	103.00	EUR
493	14	151	99	64.96	EUR
494	12	165	5	302.88	EUR
495	121	4	41	714.64	EUR
496	70	85	27	397.26	EUR
497	193	21	91	178.98	EUR
498	139	164	72	672.76	EUR
499	89	128	74	409.11	EUR
500	17	35	17	19.96	EUR
501	157	10	62	83.66	EUR
502	178	169	90	513.45	EUR
503	144	185	11	593.27	EUR
504	124	43	36	623.27	EUR
505	124	20	54	28.66	EUR
506	29	12	36	528.49	EUR
507	106	32	7	650.82	EUR
508	169	61	61	646.97	EUR
509	125	65	99	121.50	EUR
510	74	72	24	724.70	EUR
511	118	157	95	311.33	EUR
512	185	112	44	766.20	EUR
513	154	152	83	372.20	EUR
514	84	39	48	789.94	EUR
515	148	200	85	406.45	EUR
516	127	69	58	629.15	EUR
517	117	105	28	390.11	EUR
518	162	170	14	595.47	EUR
519	78	102	26	397.50	EUR
520	110	10	88	598.18	EUR
521	129	74	10	725.57	EUR
522	11	147	21	549.51	EUR
523	160	101	56	8.57	EUR
524	199	188	53	410.86	EUR
525	24	185	2	680.79	EUR
526	80	58	50	292.65	EUR
527	137	112	70	547.40	EUR
528	173	161	70	275.34	EUR
529	13	191	29	796.58	EUR
530	136	174	60	607.23	EUR
531	154	199	3	42.14	EUR
532	163	114	63	504.86	EUR
533	148	12	47	657.37	EUR
534	117	174	89	340.29	EUR
535	71	195	59	30.08	EUR
536	104	39	6	227.16	EUR
537	189	134	70	134.70	EUR
538	2	163	50	604.11	EUR
539	58	104	96	1.12	EUR
540	120	167	61	780.43	EUR
541	6	126	94	285.65	EUR
542	107	26	36	591.62	EUR
543	111	51	52	548.12	EUR
544	129	192	30	88.14	EUR
545	82	100	46	457.56	EUR
546	158	33	69	489.58	EUR
547	135	76	99	408.42	EUR
548	71	51	7	141.11	EUR
549	40	48	32	196.44	EUR
550	62	187	43	172.25	EUR
551	100	93	60	734.01	EUR
552	61	182	38	643.75	EUR
553	15	53	37	418.73	EUR
554	142	103	50	29.08	EUR
555	19	53	98	93.18	EUR
556	112	180	71	429.99	EUR
557	8	51	73	59.28	EUR
558	113	186	27	525.40	EUR
559	104	45	17	118.43	EUR
560	96	53	14	189.23	EUR
561	73	119	18	113.97	EUR
562	64	6	51	749.38	EUR
563	190	100	94	108.22	EUR
564	75	61	95	747.00	EUR
565	8	154	16	117.15	EUR
566	115	94	26	543.54	EUR
567	159	98	4	251.00	EUR
568	161	57	84	632.90	EUR
569	116	179	41	282.00	EUR
570	10	72	83	417.12	EUR
571	126	37	18	562.01	EUR
572	36	20	92	387.73	EUR
573	114	67	60	488.30	EUR
574	5	61	89	480.22	EUR
575	181	75	91	655.74	EUR
576	153	46	8	471.71	EUR
577	23	18	4	75.53	EUR
578	35	52	37	55.43	EUR
579	110	70	98	694.54	EUR
580	138	197	17	555.35	EUR
581	24	74	74	384.84	EUR
582	101	72	71	387.22	EUR
583	196	85	1	591.07	EUR
584	71	156	94	224.08	EUR
585	129	190	95	256.13	EUR
586	128	105	43	196.94	EUR
587	54	112	47	74.43	EUR
588	117	163	14	194.92	EUR
589	118	49	59	35.39	EUR
590	92	103	72	111.51	EUR
591	148	189	56	277.55	EUR
592	33	180	47	164.16	EUR
593	93	42	44	114.09	EUR
594	22	76	1	325.34	EUR
595	177	146	29	133.71	EUR
596	103	199	49	372.77	EUR
597	62	61	47	790.52	EUR
598	150	84	91	720.33	EUR
599	105	127	40	222.73	EUR
600	185	156	65	535.12	EUR
\.


--
-- TOC entry 2885 (class 0 OID 16386)
-- Dependencies: 197
-- Data for Name: product; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.product (id, name, currency, price) FROM stdin;
1	Cheese - Oka	EUR	2.99
2	Appetizer - Southwestern	EUR	3.50
3	Tea - Mint	EUR	5.07
4	Soup - Boston Clam Chowder	EUR	3.40
5	Wine - Lamancha Do Crianza	EUR	6.20
6	Cheese - Augre Des Champs	EUR	0.36
7	Beer - Mill St Organic	EUR	2.51
8	Shrimp - Black Tiger 13/15	EUR	6.53
9	Lettuce - Romaine	EUR	4.52
10	Soup - Campbells Asian Noodle	EUR	1.81
11	Veal - Inside, Choice	EUR	9.36
12	Mint - Fresh	EUR	2.10
13	Urban Zen Drinks	EUR	8.26
14	Uniform Linen Charge	EUR	6.34
15	Hummus - Spread	EUR	3.49
16	Nescafe - Frothy French Vanilla	EUR	4.99
17	Coffee - Colombian, Portioned	EUR	5.17
18	Tart - Lemon	EUR	0.62
19	Pepsi - 600ml	EUR	4.55
20	Soup - Campbells Bean Medley	EUR	3.43
21	Puree - Pear	EUR	0.69
22	Pie Box - Cello Window 2.5	EUR	7.39
23	Wine - Alsace Riesling Reserve	EUR	4.53
24	Potato - Sweet	EUR	7.29
25	Quiche Assorted	EUR	0.45
26	Beef - Ground Medium	EUR	8.48
27	Potatoes - Pei 10 Oz	EUR	4.77
28	Longos - Greek Salad	EUR	4.28
29	Pasta - Rotini, Colour, Dry	EUR	3.71
30	Mix - Cappucino Cocktail	EUR	4.16
31	Wine - George Duboeuf Rose	EUR	4.95
32	Spaghetti Squash	EUR	1.32
33	Wine - Marlbourough Sauv Blanc	EUR	9.50
34	Cinnamon - Stick	EUR	6.26
35	Cheese - Woolwich Goat, Log	EUR	3.19
36	Cassis	EUR	1.90
37	Potatoes - Pei 10 Oz	EUR	7.23
38	Maintenance Removal Charge	EUR	7.12
39	Plate Pie Foil	EUR	8.75
40	Turkey - Whole, Fresh	EUR	6.69
41	Lamb - Whole Head Off	EUR	3.60
42	Skirt - 29 Foot	EUR	3.91
43	Cod - Black Whole Fillet	EUR	6.10
44	Cake - Sheet Strawberry	EUR	2.45
45	Juice - Grape, White	EUR	5.63
46	Peas - Frozen	EUR	8.17
47	Scallops - Live In Shell	EUR	1.24
48	Cheese - Parmesan Grated	EUR	6.80
49	Currants	EUR	4.48
50	Macaroons - Homestyle Two Bit	EUR	7.05
51	Venison - Denver Leg Boneless	EUR	8.90
52	Uniform Linen Charge	EUR	7.34
53	Containter - 3oz Microwave Rect.	EUR	1.58
54	Mushroom - Crimini	EUR	8.92
55	Chicken - Ground	EUR	9.75
56	Venison - Striploin	EUR	8.06
57	Salami - Genova	EUR	0.52
58	Barramundi	EUR	2.11
59	Wine - Sawmill Creek Autumn	EUR	0.78
60	French Pastries	EUR	9.37
61	Oranges - Navel, 72	EUR	1.60
62	Potatoes - Pei 10 Oz	EUR	5.70
63	Jicama	EUR	9.27
64	Pork - Tenderloin, Fresh	EUR	5.70
65	Wine - Conde De Valdemar	EUR	9.99
66	Tart Shells - Sweet, 4	EUR	3.10
67	Island Oasis - Raspberry	EUR	9.74
68	Soup - Campbells, Lentil	EUR	9.77
69	Vinegar - Champagne	EUR	6.02
70	Orange Roughy 6/8 Oz	EUR	6.77
71	Tray - 12in Rnd Blk	EUR	9.05
72	Soup - Campbells, Butternut	EUR	3.33
73	Coconut Milk - Unsweetened	EUR	2.31
74	Coke - Diet, 355 Ml	EUR	1.74
75	Muffin - Mix - Creme Brule 15l	EUR	7.93
76	Soup - Campbells Beef Noodle	EUR	0.07
77	Munchies Honey Sweet Trail Mix	EUR	1.01
78	Creme De Menth - White	EUR	1.73
79	Lettuce - Romaine, Heart	EUR	2.17
80	Soup - Campbells Chicken	EUR	8.78
81	Veal - Brisket, Provimi, Bone - In	EUR	5.18
82	Gatorade - Fruit Punch	EUR	7.44
83	Cocktail Napkin Blue	EUR	7.24
84	Oil - Shortening,liqud, Fry	EUR	2.02
85	Beer - Blue	EUR	4.23
86	Honey - Liquid	EUR	6.87
87	Bay Leaf Fresh	EUR	7.49
88	Grouper - Fresh	EUR	9.91
89	Glass - Wine, Plastic, Clear 5 Oz	EUR	4.67
90	Sping Loaded Cup Dispenser	EUR	5.12
91	Wine - Cousino Macul Antiguas	EUR	3.74
92	Pears - Anjou	EUR	8.58
93	Beef - Tenderloin	EUR	7.72
94	Beer - True North Strong Ale	EUR	4.96
95	Sour Cream	EUR	2.24
96	Teriyaki Sauce	EUR	7.39
97	Bread - White, Unsliced	EUR	1.60
98	Bread - Pumpernickel	EUR	3.66
99	Rootbeer	EUR	3.18
100	Beer - Camerons Auburn	EUR	4.36
101	Duck - Legs	EUR	5.29
102	Cheese - Brie, Triple Creme	EUR	8.78
103	Calypso - Strawberry Lemonade	EUR	8.90
104	Bagelers	EUR	8.27
105	Wine - Prem Select Charddonany	EUR	3.66
106	Ham - Procutinni	EUR	6.35
107	Wonton Wrappers	EUR	4.25
108	Berry Brulee	EUR	1.93
109	Mackerel Whole Fresh	EUR	4.11
110	Broom - Corn	EUR	6.51
111	Waffle Stix	EUR	2.17
112	Chicken - Leg, Boneless	EUR	3.39
113	Liquid Aminios Acid - Braggs	EUR	3.15
114	Huck Towels White	EUR	9.84
115	Ice Cream Bar - Oreo Sandwich	EUR	8.89
116	Foil - Round Foil	EUR	2.75
117	Table Cloth 90x90 Colour	EUR	9.70
118	Chocolate - Semi Sweet	EUR	5.90
119	Muffin - Mix - Bran And Maple 15l	EUR	2.97
120	Wine - Wyndham Estate Bin 777	EUR	9.25
121	Compound - Pear	EUR	6.55
122	Soup - Campbells, Chix Gumbo	EUR	9.12
123	Tamarillo	EUR	0.74
124	Wine - Barolo Fontanafredda	EUR	7.89
125	Pepper - White, Ground	EUR	7.66
126	Pepper - Scotch Bonnet	EUR	1.46
127	Onion - Dried	EUR	5.89
128	Sauce - Demi Glace	EUR	2.70
129	Otomegusa Dashi Konbu	EUR	6.86
130	Doilies - 8, Paper	EUR	5.27
131	Foil Wrap	EUR	1.00
132	Gatorade - Orange	EUR	7.13
133	Apple - Fuji	EUR	2.47
134	Cheese - St. Paulin	EUR	9.52
135	Coffee - French Vanilla Frothy	EUR	3.07
136	Milk 2% 500 Ml	EUR	1.86
137	Wine - White, Ej Gallo	EUR	2.49
138	Soup - Campbells, Cream Of	EUR	1.32
139	Bacardi Breezer - Strawberry	EUR	8.89
140	Tomatoes - Diced, Canned	EUR	8.79
141	Pork - Smoked Back Bacon	EUR	3.16
142	Tamarind Paste	EUR	5.53
143	Beef - Tenderloin Tails	EUR	7.13
144	Bamboo Shoots - Sliced	EUR	3.72
145	Wine - White Cab Sauv.on	EUR	6.40
146	Shrimp - Black Tiger 13/15	EUR	0.16
147	Appetizer - Tarragon Chicken	EUR	4.48
148	Energy Drink - Franks Pineapple	EUR	2.46
149	Longos - Grilled Chicken With	EUR	4.22
150	Veal - Brisket, Provimi,bnls	EUR	5.11
151	Nantuket Peach Orange	EUR	0.52
152	Nantucket Cranberry Juice	EUR	4.94
153	Basil - Primerba, Paste	EUR	1.31
154	Wine - White, Schroder And Schyl	EUR	7.74
155	Garam Masala Powder	EUR	4.47
156	Chocolate - Unsweetened	EUR	9.00
157	Bread - Sour Batard	EUR	0.52
158	Jello - Assorted	EUR	5.16
159	Beef - Sushi Flat Iron Steak	EUR	4.20
160	Coconut - Creamed, Pure	EUR	9.81
161	Pasta - Lasagna, Dry	EUR	4.15
162	Beef - Inside Round	EUR	8.41
163	Cake - Box Window 10x10x2.5	EUR	5.11
164	Sauce - Mint	EUR	4.67
165	Turkey - Oven Roast Breast	EUR	1.73
166	Doilies - 7, Paper	EUR	4.06
167	Flour - Fast / Rapid	EUR	4.67
168	Bagelers	EUR	3.39
169	Wine - Pinot Noir Stoneleigh	EUR	9.79
170	Soup - Beef Conomme, Dry	EUR	1.92
171	Wine - White, Schroder And Schyl	EUR	1.83
172	Juice - Apple 284ml	EUR	9.00
173	Lamb - Whole Head Off	EUR	2.74
174	Onions - Cooking	EUR	3.14
175	Beef - Tongue, Fresh	EUR	2.86
176	Dill Weed - Dry	EUR	7.27
177	Kale - Red	EUR	2.09
178	Pepper - Black, Ground	EUR	6.34
179	Wine - Beaujolais Villages	EUR	1.10
180	7up Diet, 355 Ml	EUR	8.58
181	Bagel - Sesame Seed Presliced	EUR	9.72
182	Olive - Spread Tapenade	EUR	4.77
183	Soup - Campbells Chili Veg	EUR	4.82
184	Longos - Grilled Chicken With	EUR	6.77
185	Yucca	EUR	5.15
186	Chocolate - Milk Coating	EUR	8.62
187	Magnotta Bel Paese Red	EUR	4.11
188	Graham Cracker Mix	EUR	1.74
189	Cucumber - English	EUR	9.41
190	Veal - Osso Bucco	EUR	1.44
191	Mushroom - Trumpet, Dry	EUR	9.92
192	Spring Roll Veg Mini	EUR	0.76
193	Cheese - Mozzarella, Buffalo	EUR	5.83
194	Cinnamon - Stick	EUR	9.00
195	Beef - Tenderloin Tails	EUR	8.55
196	Tea - Vanilla Chai	EUR	1.88
197	Lamb - Loin, Trimmed, Boneless	EUR	9.64
198	Wine - Riesling Dr. Pauly	EUR	5.89
199	Muffin Mix - Lemon Cranberry	EUR	0.88
200	Bread - Multigrain Oval	EUR	3.39
\.


--
-- TOC entry 2898 (class 0 OID 0)
-- Dependencies: 198
-- Name: customer_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.customer_id_seq', 200, true);


--
-- TOC entry 2899 (class 0 OID 0)
-- Dependencies: 200
-- Name: customer_order_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.customer_order_id_seq', 600, true);


--
-- TOC entry 2900 (class 0 OID 0)
-- Dependencies: 196
-- Name: product_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.product_id_seq', 200, true);


--
-- TOC entry 2760 (class 2606 OID 16407)
-- Name: customer_order customer_order_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer_order
    ADD CONSTRAINT customer_order_pkey PRIMARY KEY (id);


--
-- TOC entry 2758 (class 2606 OID 16399)
-- Name: customer customer_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer
    ADD CONSTRAINT customer_pkey PRIMARY KEY (id);


--
-- TOC entry 2756 (class 2606 OID 16391)
-- Name: product product_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product
    ADD CONSTRAINT product_pkey PRIMARY KEY (id);


--
-- TOC entry 2761 (class 2606 OID 16408)
-- Name: customer_order customer_order_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer_order
    ADD CONSTRAINT customer_order_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customer(id);


--
-- TOC entry 2762 (class 2606 OID 16413)
-- Name: customer_order customer_order_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer_order
    ADD CONSTRAINT customer_order_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.product(id);


-- Completed on 2023-12-11 17:06:40 UTC

--
-- PostgreSQL database dump complete
--

